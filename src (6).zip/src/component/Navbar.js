import React from 'react';
import logo from '../logo.png';


function Navbar() {
    return (
    
   
<header><div className="container">
  <a href="/"><img src={logo} alt="logo"/></a>
  </div></header>     
  
    );
  }
  

  export default Navbar;


 