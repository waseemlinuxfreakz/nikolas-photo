import React from 'react';
import { useState } from 'react';




function Cards(props) {

  /*const [show, setShow] = useState(false);*/

  
  /*const handleClick = (e) => {
    //handleClick(e) {
      e.preventDefault()
      console.log(e.target.getAttribute('data-id'));
      //alert(e.target.getAttribute('data-id'));
    }*/
   //console.log(props); 
  
   


  return (
    
    <></>   
  
    );
  }
  
  export default Cards;
  